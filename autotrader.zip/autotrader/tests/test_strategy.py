"""
test_strategy.py — 핵심 로직 pytest 유닛 테스트
외부 API 의존 없이 내부 로직만 검증
"""
import pytest
from src.indicators import (
    Candle, ORBState, VWAPCalculator, SMACalculator,
    VolumeRatioCalculator, SymbolIndicators,
)
from src.strategy import StrategyEngine, SignalType, ScoreResult
from src.risk_manager import RiskManager, Position


# ──────────────────────────────────────────────
#  fixtures
# ──────────────────────────────────────────────
@pytest.fixture
def config():
    return {
        "strategy": {
            "min_score": 3,
            "volume_multiplier": 1.5,
            "require_vwap_above": True,
            "ma_short": 5,
            "ma_long": 20,
        },
        "take_profit": {
            "tp1_pct": 1.5, "tp1_size": 0.5,
            "tp2_pct": 3.0, "tp2_size": 0.3,
            "tp3_pct": 5.0, "tp3_size": 1.0,
        },
        "stop_loss": {"sl_pct": 1.0, "vwap_stop": True},
        "risk": {
            "risk_per_trade_pct": 1.5,
            "max_position_pct": 50.0,
            "max_concurrent": 2,
            "max_daily_trades": 8,
            "daily_loss_limit_pct": 3.0,
            "monthly_loss_limit_pct": 10.0,
            "consecutive_loss_limit": 3,
        },
    }


def make_candle(close: float, volume: int = 1000, high: float = 0, low: float = 0) -> Candle:
    h = high or close * 1.005
    l = low  or close * 0.995
    return Candle(time="093000", open=close * 0.998, high=h, low=l, close=close, volume=volume)


# ──────────────────────────────────────────────
#  ORB 테스트
# ──────────────────────────────────────────────
class TestORB:
    def test_not_ready_before_set(self):
        orb = ORBState()
        orb.update(make_candle(10000))
        assert not orb.is_breakout(10100)

    def test_breakout_detected(self):
        orb = ORBState()
        orb.update(make_candle(10000, high=10050))
        orb.ready = True
        assert orb.is_breakout(10100)
        assert not orb.is_breakout(9900)

    def test_high_low_tracking(self):
        orb = ORBState()
        orb.update(make_candle(10000, high=10200, low=9800))
        orb.update(make_candle(10100, high=10300, low=9900))
        assert orb.high == pytest.approx(10300)
        assert orb.low  == pytest.approx(9800)


# ──────────────────────────────────────────────
#  VWAP 테스트
# ──────────────────────────────────────────────
class TestVWAP:
    def test_single_candle(self):
        vwap = VWAPCalculator()
        c = Candle("093000", 9900, 10100, 9900, 10000, 1000)
        result = vwap.update(c)
        expected = (10100 + 9900 + 10000) / 3
        assert result == pytest.approx(expected)

    def test_multiple_candles_weighted(self):
        vwap = VWAPCalculator()
        c1 = Candle("093000", 9900, 10000, 9900, 10000, 100)
        c2 = Candle("093500", 9900, 11000, 9900, 11000, 900)
        vwap.update(c1)
        result = vwap.update(c2)
        # 거래량 가중: 낮은 거래량 봉보다 높은 거래량 봉 가격에 더 가까워야 함
        assert result > (10000 + 11000) / 2

    def test_reset(self):
        vwap = VWAPCalculator()
        vwap.update(make_candle(10000))
        vwap.reset()
        assert vwap.value == 0.0


# ──────────────────────────────────────────────
#  SMA 테스트
# ──────────────────────────────────────────────
class TestSMA:
    def test_insufficient_data(self):
        sma = SMACalculator(5)
        sma.update(100.0)
        assert sma.value is None

    def test_exact_period(self):
        sma = SMACalculator(3)
        for v in [10.0, 20.0, 30.0]:
            sma.update(v)
        assert sma.value == pytest.approx(20.0)

    def test_rolling_window(self):
        sma = SMACalculator(3)
        for v in [10.0, 20.0, 30.0, 40.0]:
            sma.update(v)
        assert sma.value == pytest.approx(30.0)   # (20+30+40)/3

    def test_is_rising(self):
        sma = SMACalculator(3)
        for v in [10.0, 20.0, 30.0]:
            sma.update(v)
        assert sma.is_rising()

    def test_is_not_rising(self):
        sma = SMACalculator(3)
        for v in [30.0, 20.0, 10.0]:
            sma.update(v)
        assert not sma.is_rising()


# ──────────────────────────────────────────────
#  거래량 배율 테스트
# ──────────────────────────────────────────────
class TestVolumeRatio:
    def test_insufficient_data(self):
        vr = VolumeRatioCalculator(3)
        vr.update(100)
        assert vr.current_ratio() == 0.0

    def test_ratio_calculation(self):
        vr = VolumeRatioCalculator(3)
        for v in [100, 100, 100]:     # 직전 3봉 평균 = 100
            vr.update(v)
        vr.update(200)                # 최신봉 = 200 → 비율 2.0
        assert vr.current_ratio() == pytest.approx(2.0)


# ──────────────────────────────────────────────
#  StrategyEngine 테스트
# ──────────────────────────────────────────────
class TestStrategyEngine:
    def test_score_zero_no_data(self, config):
        engine = StrategyEngine(config)
        ind = SymbolIndicators("005930")
        score = engine.score_entry(ind, 10000)
        assert score.score == 0

    def test_exit_sl_triggered(self, config):
        engine = StrategyEngine(config)
        # -1.5% 손실 → 손절 신호
        signal = engine.check_exit(
            entry_price=10000, current_price=9850,
            vwap_value=0,
        )
        assert signal == SignalType.EXIT_SL

    def test_exit_vwap_stop(self, config):
        engine = StrategyEngine(config)
        # 가격이 VWAP 아래로 → 손절
        signal = engine.check_exit(
            entry_price=10000, current_price=9999,
            vwap_value=10100,
        )
        assert signal == SignalType.EXIT_SL

    def test_exit_tp1(self, config):
        engine = StrategyEngine(config)
        signal = engine.check_exit(
            entry_price=10000, current_price=10160,   # +1.6%
            vwap_value=0,
        )
        assert signal == SignalType.EXIT_TP1

    def test_exit_tp2(self, config):
        engine = StrategyEngine(config)
        signal = engine.check_exit(
            entry_price=10000, current_price=10310,   # +3.1%
            vwap_value=0, tp1_done=True,
        )
        assert signal == SignalType.EXIT_TP2

    def test_no_signal_in_profit(self, config):
        engine = StrategyEngine(config)
        signal = engine.check_exit(
            entry_price=10000, current_price=10050,   # +0.5% — 아직 익절 미도달
            vwap_value=0,
        )
        assert signal == SignalType.NONE

    def test_exit_qty_tp1(self, config):
        engine = StrategyEngine(config)
        qty = engine.exit_qty(100, SignalType.EXIT_TP1)
        assert qty == 50   # tp1_size=0.5

    def test_exit_qty_sl_all(self, config):
        engine = StrategyEngine(config)
        qty = engine.exit_qty(100, SignalType.EXIT_SL)
        assert qty == 100


# ──────────────────────────────────────────────
#  RiskManager 테스트
# ──────────────────────────────────────────────
class TestRiskManager:
    def test_position_sizing(self, config):
        rm = RiskManager(config, 10_000_000)
        # 리스크 기준: 150,000 / 100원 = 1500주
        # 자본 상한: 5,000,000 / 10,000 = 500주
        # min(1500, 500) = 500 (max_position_pct 50% 상한 적용)
        qty = rm.calc_position_size(10000)
        assert qty == 500

    def test_position_cap(self, config):
        rm = RiskManager(config, 1_000_000)   # 소액 자본
        qty = rm.calc_position_size(100000)   # 고가 종목
        # 상한: 1,000,000 * 50% / 100,000 = 5주
        assert qty <= 5

    def test_daily_loss_limit(self, config):
        from src.risk_manager import RiskState
        rm = RiskManager(config, 10_000_000)
        rm.daily.pnl = -400_000   # -4% → 한도(-3%) 초과
        assert rm.check_state() == RiskState.DAILY_HALTED

    def test_consecutive_loss_limit(self, config):
        from src.risk_manager import RiskState
        rm = RiskManager(config, 10_000_000)
        rm.daily.consec_loss = 3
        assert rm.check_state() == RiskState.LOSING_STREAK

    def test_max_concurrent(self, config):
        from src.risk_manager import RiskState
        rm = RiskManager(config, 10_000_000)
        for i in range(2):
            pos = Position(
                symbol=f"00000{i}", entry_price=10000,
                qty=100, entry_time="09:30:00"
            )
            rm.open_position(pos)
        assert rm.check_state() == RiskState.MAX_CONCURRENT

    def test_can_enter_false_when_halted(self, config):
        rm = RiskManager(config, 10_000_000)
        rm.daily.pnl = -500_000
        assert not rm.can_enter()

    def test_close_position_updates_stats(self, config):
        rm = RiskManager(config, 10_000_000)
        pos = Position(symbol="005930", entry_price=10000, qty=100, entry_time="09:30:00")
        rm.open_position(pos)
        pnl = rm.close_position("005930", 10100)
        assert pnl == pytest.approx(10000.0)   # 100 * 100
        assert rm.daily.wins == 1
        assert rm.daily.consec_loss == 0
