"""
main.py — 공격적 스켈핑 자동매매 오케스트레이터
KIS Developers API 기반 ORB + VWAP + 거래량폭증 3중 필터 전략

실행:
    python main.py              # 모의투자 실운용
    python main.py --dry-run    # 드라이런 (주문 없이 신호만 출력)
    python main.py --once       # 1회 루프 후 종료 (테스트용)
"""
from __future__ import annotations

import argparse
import logging
import os
import sys
import time
from pathlib import Path

import yaml
from dotenv import load_dotenv

# ── 로컬 모듈 임포트 ─────────────────────────────────────────
from src.utils import setup_logger, now_kst, time_between, str_to_time, is_market_open
from src.auth import KISAuth
from src.kis_client import KISClient
from src.indicators import SymbolIndicators, parse_candle_from_api
from src.strategy import StrategyEngine
from src.screener import Screener
from src.risk_manager import RiskManager
from src.executor import Executor
from src.journal import TradeJournal
from src.notifier import Notifier


# ──────────────────────────────────────────────────────────────
#  설정 로드
# ──────────────────────────────────────────────────────────────
def load_config(path: str = "config.yaml") -> dict:
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


# ──────────────────────────────────────────────────────────────
#  메인 루프
# ──────────────────────────────────────────────────────────────
class AutoTrader:
    """스켈핑 자동매매 메인 루프"""

    def __init__(self, config: dict, dry_run: bool = False) -> None:
        self.config  = config
        self.dry_run = dry_run

        log_cfg = config.get("logging", {})
        self.logger = setup_logger(
            level   = log_cfg.get("level", "INFO"),
            log_dir = log_cfg.get("log_dir", "logs"),
        )

        # KIS 인증 & 클라이언트
        self.auth    = KISAuth()
        self.client  = KISClient(self.auth)

        # 전략 / 리스크 / 유틸 모듈
        self.strategy = StrategyEngine(config)
        self.journal  = TradeJournal(log_cfg.get("journal_dir", "data/journal"))
        self.notifier = Notifier()

        # 자본금 초기화
        initial_capital = self._fetch_capital()
        self.risk = RiskManager(config, initial_capital)

        # 주문 실행기
        self.executor = Executor(
            client   = self.client,
            risk     = self.risk,
            strategy = self.strategy,
            journal  = self.journal,
            notifier = self.notifier,
            config   = config,
            dry_run  = dry_run,
        )

        # 스크리너
        self.screener = Screener(self.client, config)

        # 종목별 지표 저장소
        self.indicators: dict[str, SymbolIndicators] = {}

        # 타임 설정
        strat = config.get("strategy", {})
        orb   = config.get("orb", {})
        self.orb_start:     str = orb.get("start_time",    "09:00")
        self.orb_end:       str = orb.get("end_time",      "09:30")
        self.trade_start:   str = strat.get("trading_start", "09:30")
        self.trade_end:     str = strat.get("trading_end",   "11:00")
        self.force_close:   str = strat.get("force_close",   "15:15")
        self.poll_interval: int = int(config.get("polling", {}).get("price_interval_sec", 15))

        self._screened_today = False
        self._orb_set:   set[str] = set()    # ORB 완성된 종목
        self._daily_reset_done = False

    # ── 자본금 조회 ───────────────────────────────────────────
    def _fetch_capital(self) -> float:
        try:
            cash = self.client.get_cash()
            self.logger.info("초기 자본금: %.0f원", cash)
            return cash if cash > 0 else 10_000_000   # 기본값 1천만
        except Exception as e:
            self.logger.warning("자본금 조회 실패 (%s) → 기본값 1천만원 사용", e)
            return 10_000_000.0

    # ── 지표 초기화 ───────────────────────────────────────────
    def _init_indicators(self, symbol: str) -> None:
        if symbol not in self.indicators:
            strat_cfg = self.config.get("strategy", {})
            self.indicators[symbol] = SymbolIndicators(
                symbol,
                ma_short = int(strat_cfg.get("ma_short", 5)),
                ma_long  = int(strat_cfg.get("ma_long",  20)),
            )

    # ── 분봉 업데이트 ─────────────────────────────────────────
    def _update_candles(self, symbol: str) -> None:
        """KIS API에서 최신 분봉 가져와 지표 업데이트"""
        ind = self.indicators[symbol]
        try:
            rows = self.client.get_minute_candles(symbol)
            if not rows:
                return

            in_orb = time_between(self.orb_start, self.orb_end)

            for row in reversed(rows):          # 과거 → 최신 순
                candle = parse_candle_from_api(row)
                if candle and candle.volume > 0:
                    ind.add_candle(candle, in_orb_window=in_orb)

        except Exception as e:
            self.logger.warning("[%s] 분봉 업데이트 실패: %s", symbol, e)

    # ── 메인 루프 ─────────────────────────────────────────────
    def run(self, once: bool = False) -> None:
        mode_str = "DRY-RUN" if self.dry_run else self.auth.mode.upper()
        self.logger.info("=== 자동매매 시작 [%s] ===", mode_str)
        self.notifier.send(f"🤖 자동매매 시작 [{mode_str}]")

        try:
            while True:
                self._tick()
                if once:
                    break
                time.sleep(self.poll_interval)

        except KeyboardInterrupt:
            self.logger.info("사용자 종료 요청")
        finally:
            self._shutdown()

    def _tick(self) -> None:
        """폴링 1회"""
        now = now_kst()
        now_str = now.strftime("%H:%M:%S")

        # 시장 외 시간 — 스킵
        if not is_market_open():
            self.logger.debug("[%s] 시장 외 시간", now_str)
            return

        # 일일 초기화 (09:00 직후 1회)
        if time_between("09:00", "09:01") and not self._daily_reset_done:
            self.risk.reset_daily()
            self._screened_today = False
            self._orb_set.clear()
            self.indicators.clear()
            self._daily_reset_done = True
        elif not time_between("09:00", "09:01"):
            self._daily_reset_done = False

        # 강제 청산 (15:15)
        if now.strftime("%H:%M") >= self.force_close:
            if self.risk.positions:
                self.logger.info("[%s] 강제 청산 실행", now_str)
                self.executor.force_close_all()
                # 일일 결산
                summary = self.journal.get_daily_summary()
                self.notifier.send_daily_report(summary)
            return

        # ── ORB 구간 (09:00~09:30): 관찰만 ──────────────────
        if time_between(self.orb_start, self.orb_end):
            for sym in list(self.indicators.keys()):
                self._update_candles(sym)
            return

        # ── ORB 종료 직후: orb.ready 플래그 세팅 ────────────
        if time_between("09:30", "09:31"):
            for sym, ind in self.indicators.items():
                if sym not in self._orb_set and not ind.orb.ready:
                    ind.set_orb_ready()
                    self._orb_set.add(sym)

        # ── 스크리닝 (09:30~09:35, 1회) ──────────────────────
        if time_between(self.trade_start, "09:35") and not self._screened_today:
            self.logger.info("종목 스크리닝 시작")
            candidates = self.screener.screen()
            for c in candidates:
                self._init_indicators(c.symbol)
                self._update_candles(c.symbol)
                ind = self.indicators[c.symbol]
                ind.set_orb_ready()
                self._orb_set.add(c.symbol)
            self._screened_today = True
            self.logger.info("스크리닝 완료: %s", [c.symbol for c in candidates])

        # ── 지표 업데이트 ─────────────────────────────────────
        for sym in list(self.indicators.keys()):
            self._update_candles(sym)

        # ── 보유 포지션 청산 신호 처리 ────────────────────────
        for sym, pos in list(self.risk.positions.items()):
            ind = self.indicators.get(sym)
            if not ind:
                continue
            try:
                price_data = self.client.get_price(sym)
                current = int(price_data.get("stck_prpr", 0))
                if current > 0:
                    self.executor.process_signal(pos, ind, current)
            except Exception as e:
                self.logger.error("[%s] 청산 처리 오류: %s", sym, e)

        # ── 진입 신호 탐색 (09:30~11:00) ─────────────────────
        if not time_between(self.trade_start, self.trade_end):
            return

        for sym, ind in self.indicators.items():
            if sym in self.risk.positions:
                continue   # 이미 보유 중
            if not self.risk.can_enter():
                break

            try:
                price_data = self.client.get_price(sym)
                orderbook  = self.client.get_orderbook(sym)

                current = int(price_data.get("stck_prpr", 0))
                if current <= 0:
                    continue

                ask_total = int(orderbook.get("total_askp_rsqn", 0))
                bid_total = int(orderbook.get("total_bidp_rsqn", 0))

                should_enter, score = self.strategy.should_enter(
                    ind, float(current), ask_total, bid_total
                )
                if should_enter:
                    self.executor.enter(sym, current, score=score.score)

            except Exception as e:
                self.logger.error("[%s] 진입 탐색 오류: %s", sym, e)

    # ── 종료 처리 ─────────────────────────────────────────────
    def _shutdown(self) -> None:
        self.logger.info("=== 자동매매 종료 ===")
        risk_summary = self.risk.summary()
        self.logger.info("리스크 요약: %s", risk_summary)

        journal_summary = self.journal.get_daily_summary()
        if journal_summary.get("trades", 0) > 0:
            self.notifier.send_daily_report(journal_summary)

        self.notifier.send("🛑 자동매매 종료")


# ──────────────────────────────────────────────────────────────
#  진입점
# ──────────────────────────────────────────────────────────────
def main() -> None:
    parser = argparse.ArgumentParser(description="KIS 스켈핑 자동매매")
    parser.add_argument("--dry-run", action="store_true", help="주문 없이 신호만 출력")
    parser.add_argument("--once",    action="store_true", help="1회 루프 후 종료 (테스트)")
    parser.add_argument("--config",  default="config.yaml", help="설정 파일 경로")
    args = parser.parse_args()

    # 환경변수 로드
    load_dotenv()

    # 현재 디렉토리를 autotrader/ 로 강제
    script_dir = Path(__file__).parent
    os.chdir(script_dir)

    config = load_config(args.config)
    trader = AutoTrader(config, dry_run=args.dry_run)
    trader.run(once=args.once)


if __name__ == "__main__":
    main()
