"""
auth.py — KIS Developers OAuth 토큰 / approval_key 관리
"""
from __future__ import annotations

import os
import time
import logging
import requests
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo

KST = ZoneInfo("Asia/Seoul")
logger = logging.getLogger("autotrader.auth")

# KIS API 기본 URL
_PAPER_BASE = "https://openapivts.koreainvestment.com:29443"
_REAL_BASE  = "https://openapi.koreainvestment.com:9443"


class KISAuth:
    """KIS Developers OAuth 토큰 관리 클래스

    사용 예::

        auth = KISAuth()
        headers = auth.get_headers()
        approval_key = auth.get_approval_key()
    """

    def __init__(self) -> None:
        self.mode: str = os.getenv("TRADE_MODE", "paper").lower()

        if self.mode == "real":
            self.app_key    = os.environ["KIS_REAL_APP_KEY"]
            self.app_secret = os.environ["KIS_REAL_APP_SECRET"]
            self.cano       = os.environ["KIS_REAL_CANO"]
            self.acnt_prdt  = os.environ.get("KIS_REAL_ACNT_PRDT_CD", "01")
            self.base_url   = _REAL_BASE
        else:
            self.app_key    = os.environ["KIS_PAPER_APP_KEY"]
            self.app_secret = os.environ["KIS_PAPER_APP_SECRET"]
            self.cano       = os.environ["KIS_PAPER_CANO"]
            self.acnt_prdt  = os.environ.get("KIS_PAPER_ACNT_PRDT_CD", "01")
            self.base_url   = _PAPER_BASE

        self._access_token: str | None = None
        self._token_expires: datetime  = datetime.min.replace(tzinfo=KST)
        self._approval_key: str | None = None

    # ── Access Token ─────────────────────────────────────────
    def _issue_token(self) -> None:
        """신규 access_token 발급"""
        url = f"{self.base_url}/oauth2/tokenP"
        body = {
            "grant_type": "client_credentials",
            "appkey":     self.app_key,
            "appsecret":  self.app_secret,
        }
        resp = requests.post(url, json=body, timeout=10)
        resp.raise_for_status()
        data = resp.json()

        self._access_token = data["access_token"]
        expires_in = int(data.get("expires_in", 86400))
        self._token_expires = datetime.now(tz=KST) + timedelta(seconds=expires_in - 60)
        logger.info("KIS access_token 발급 완료 (만료: %s)", self._token_expires.strftime("%H:%M:%S"))

    def get_access_token(self) -> str:
        """유효한 access_token 반환 (만료 시 자동 갱신)"""
        if not self._access_token or datetime.now(tz=KST) >= self._token_expires:
            self._issue_token()
        return self._access_token  # type: ignore[return-value]

    # ── approval_key (WebSocket 용) ───────────────────────────
    def get_approval_key(self) -> str:
        """WebSocket 연결용 approval_key 반환"""
        if self._approval_key:
            return self._approval_key

        url = f"{self.base_url}/oauth2/Approval"
        body = {
            "grant_type": "client_credentials",
            "appkey":     self.app_key,
            "secretkey":  self.app_secret,
        }
        resp = requests.post(url, json=body, timeout=10)
        resp.raise_for_status()
        self._approval_key = resp.json()["approval_key"]
        logger.info("KIS approval_key 발급 완료")
        return self._approval_key  # type: ignore[return-value]

    # ── 공통 헤더 빌더 ────────────────────────────────────────
    def get_headers(self, tr_id: str = "", content_type: str = "application/json") -> dict[str, str]:
        """REST 요청 공통 헤더 생성"""
        headers: dict[str, str] = {
            "Content-Type":  content_type,
            "authorization": f"Bearer {self.get_access_token()}",
            "appkey":        self.app_key,
            "appsecret":     self.app_secret,
        }
        if tr_id:
            headers["tr_id"] = tr_id
        return headers

    @property
    def account_no(self) -> str:
        """계좌번호 전체 (CANO + ACNT_PRDT_CD)"""
        return f"{self.cano}-{self.acnt_prdt}"
