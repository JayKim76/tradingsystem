"""
screener.py — 장 초반 종목 자동 스크리닝
갭 / 시총 / 스프레드 3중 필터
"""
from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Optional

from .kis_client import KISClient

logger = logging.getLogger("autotrader.screener")

# 기본 추적 유니버스 (시가총액 상위 + 테마 이슈 종목)
# 실제 운용 시에는 CSV 등 외부 파일로 관리하세요
_DEFAULT_UNIVERSE = [
    "005930",  # 삼성전자
    "000660",  # SK하이닉스
    "035420",  # NAVER
    "035720",  # 카카오
    "051910",  # LG화학
    "006400",  # 삼성SDI
    "028260",  # 삼성물산
    "066570",  # LG전자
    "003550",  # LG
    "096770",  # SK이노베이션
    "207940",  # 삼성바이오로직스
    "068270",  # 셀트리온
    "105560",  # KB금융
    "055550",  # 신한지주
    "000270",  # 기아
    "005380",  # 현대차
    "012330",  # 현대모비스
    "247540",  # 에코프로비엠
    "086520",  # 에코프로
    "373220",  # LG에너지솔루션
]


@dataclass
class CandidateSymbol:
    """스크리닝 통과 종목"""
    symbol:        str
    name:          str
    price:         int
    gap_pct:       float
    spread_pct:    float
    market_cap_bil: float    # 억원
    volume:        int


def default_universe() -> list[str]:
    """기본 유니버스 반환 (외부 CSV 로드 로직으로 교체 가능)"""
    return _DEFAULT_UNIVERSE.copy()


class Screener:
    """장 초반 종목 스크리닝 (09:30~09:35)"""

    def __init__(self, client: KISClient, config: dict) -> None:
        self.client = client
        univ_cfg = config.get("universe", {})
        self.min_gap_pct:       float = float(univ_cfg.get("min_gap_pct", 3.0))
        self.max_spread_pct:    float = float(univ_cfg.get("max_spread_pct", 0.1))
        self.min_cap_bil:       float = float(univ_cfg.get("min_market_cap_bil", 100))
        self.max_cap_bil:       float = float(univ_cfg.get("max_market_cap_bil", 10000))
        self.max_symbols:       int   = int(univ_cfg.get("max_symbols", 5))

    def screen(self, universe: Optional[list[str]] = None) -> list[CandidateSymbol]:
        """유니버스 종목에 대해 필터 적용 후 후보 반환"""
        symbols = universe or default_universe()
        candidates: list[CandidateSymbol] = []

        logger.info("스크리닝 시작: %d 종목", len(symbols))

        for sym in symbols:
            try:
                cand = self._evaluate(sym)
                if cand:
                    candidates.append(cand)
            except Exception as e:
                logger.warning("[%s] 스크리닝 오류: %s", sym, e)

        # 갭 내림차순 정렬
        candidates.sort(key=lambda c: c.gap_pct, reverse=True)
        result = candidates[:self.max_symbols]

        logger.info(
            "스크리닝 완료: %d/%d 통과 → 상위 %d 선택",
            len(candidates), len(symbols), len(result),
        )
        return result

    def _evaluate(self, symbol: str) -> Optional[CandidateSymbol]:
        """단일 종목 필터 평가"""
        price_data = self.client.get_price(symbol)
        if not price_data:
            return None

        # 현재가
        price = int(price_data.get("stck_prpr", 0))
        if price <= 0:
            return None

        # 전일 종가 대비 갭
        prev_close = int(price_data.get("stck_sdpr", 0))
        if prev_close <= 0:
            return None
        open_price = int(price_data.get("stck_oprc", price))
        gap_pct = (open_price - prev_close) / prev_close * 100

        if gap_pct < self.min_gap_pct:
            logger.debug("[%s] 갭 부족 %.1f%% < %.1f%%", symbol, gap_pct, self.min_gap_pct)
            return None

        # 시가총액 (억원) — 상장주식수 * 현재가 / 100_000_000
        lstg_stqt = int(price_data.get("lstn_stcn", 0))
        market_cap_bil = (lstg_stqt * price) / 1e8
        if not (self.min_cap_bil <= market_cap_bil <= self.max_cap_bil):
            logger.debug("[%s] 시총 부적합 %.0f억", symbol, market_cap_bil)
            return None

        # 호가 스프레드
        try:
            ob = self.client.get_orderbook(symbol)
            best_ask = int(ob.get("askp1", 0))
            best_bid = int(ob.get("bidp1", 0))
            if best_ask > 0 and best_bid > 0:
                mid = (best_ask + best_bid) / 2
                spread_pct = (best_ask - best_bid) / mid * 100
            else:
                spread_pct = 999.0
        except Exception:
            spread_pct = 999.0

        if spread_pct > self.max_spread_pct:
            logger.debug("[%s] 스프레드 초과 %.3f%%", symbol, spread_pct)
            return None

        volume = int(price_data.get("acml_vol", 0))
        name   = price_data.get("hts_kor_isnm", symbol)

        logger.info(
            "[%s] %s 통과 ─ 갭=%.1f%% 시총=%.0f억 스프레드=%.3f%%",
            symbol, name, gap_pct, market_cap_bil, spread_pct,
        )
        return CandidateSymbol(
            symbol         = symbol,
            name           = name,
            price          = price,
            gap_pct        = gap_pct,
            spread_pct     = spread_pct,
            market_cap_bil = market_cap_bil,
            volume         = volume,
        )

    def screen_from_volume_rank(self) -> list[CandidateSymbol]:
        """거래량 랭킹 API로부터 유니버스 자동 수집 후 스크리닝"""
        try:
            rank_data = self.client.get_volume_rank()
            symbols = [row["mksc_shrn_iscd"] for row in rank_data if row.get("mksc_shrn_iscd")]
            logger.info("거래량 랭킹 %d종목 수집", len(symbols))
            return self.screen(symbols[:50])
        except Exception as e:
            logger.error("거래량 랭킹 스크리닝 실패: %s — 기본 유니버스 사용", e)
            return self.screen()
