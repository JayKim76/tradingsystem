"""
executor.py — 주문 실행 + 분할 익절 (1.5% / 3% / 5%)
"""
from __future__ import annotations

import logging
import time
from typing import Optional

from .auth import KISAuth
from .kis_client import KISClient
from .risk_manager import RiskManager, Position
from .strategy import StrategyEngine, SignalType
from .indicators import SymbolIndicators
from .journal import TradeJournal
from .notifier import Notifier
from .utils import round_to_tick, now_kst

logger = logging.getLogger("autotrader.executor")


class Executor:
    """주문 실행 오케스트레이터"""

    def __init__(
        self,
        client: KISClient,
        risk:   RiskManager,
        strategy: StrategyEngine,
        journal: TradeJournal,
        notifier: Notifier,
        config: dict,
        dry_run: bool = False,
    ) -> None:
        self.client   = client
        self.risk     = risk
        self.strategy = strategy
        self.journal  = journal
        self.notifier = notifier
        self.dry_run  = dry_run

        exec_cfg = config.get("execution", {})
        self.order_type   = exec_cfg.get("order_type", "00")
        self.retry_count  = int(exec_cfg.get("retry_count", 3))
        self.retry_delay  = float(exec_cfg.get("retry_delay_sec", 1))
        self.slippage_bps = int(exec_cfg.get("slippage_bps", 5))

        cost_cfg = config.get("cost", {})
        self.commission_pct = float(cost_cfg.get("commission_pct", 0.015))
        self.tax_pct        = float(cost_cfg.get("tax_pct", 0.18))

    # ── 매수 진입 ─────────────────────────────────────────────
    def enter(
        self,
        symbol: str,
        price: int,
        score: int = 0,
    ) -> Optional[Position]:
        """매수 주문 실행 후 Position 반환"""
        if not self.risk.can_enter():
            return None

        qty = self.risk.calc_position_size(price)
        if qty <= 0:
            logger.warning("[%s] 포지션 사이즈 0 — 진입 취소", symbol)
            return None

        # 지정가 슬리피지 반영 (매수: 호가 위로)
        order_price = self._buy_price(price)

        logger.info(
            "[%s] 매수 진입 %d주 @%d원%s",
            symbol, qty, order_price,
            " [DRY-RUN]" if self.dry_run else "",
        )

        if not self.dry_run:
            odno = self._send_order(symbol, "BUY", qty, order_price)
            if not odno:
                return None

        pos = Position(
            symbol      = symbol,
            entry_price = float(order_price),
            qty         = qty,
            entry_time  = now_kst().strftime("%H:%M:%S"),
            score       = score,
        )
        self.risk.open_position(pos)
        self.notifier.send(
            f"📈 매수 진입\n종목: {symbol}\n{qty}주 @{order_price:,}원\n[스코어 {score}/5]"
        )
        return pos

    # ── 매도 청산 ─────────────────────────────────────────────
    def exit(
        self,
        pos: Position,
        current_price: int,
        signal: SignalType,
        note: str = "",
    ) -> float:
        """매도 주문 실행 후 PnL 반환 (원화)"""
        exit_qty = self.strategy.exit_qty(pos.qty, signal, tp1_done=pos.tp1_done)
        if exit_qty <= 0:
            return 0.0

        order_price = self._sell_price(current_price)

        reason_map = {
            SignalType.EXIT_TP1:   "TP1(+1.5%)",
            SignalType.EXIT_TP2:   "TP2(+3%)",
            SignalType.EXIT_TP3:   "TP3/5MA이탈",
            SignalType.EXIT_SL:    "손절",
            SignalType.EXIT_FORCE: "강제청산",
        }
        reason = reason_map.get(signal, signal.name)

        logger.info(
            "[%s] 매도 청산 [%s] %d주 @%d원%s",
            pos.symbol, reason, exit_qty, order_price,
            " [DRY-RUN]" if self.dry_run else "",
        )

        if not self.dry_run:
            self._send_order(pos.symbol, "SELL", exit_qty, order_price)

        pnl = self.risk.close_position(pos.symbol, float(order_price), exit_qty)

        # 익절 플래그 업데이트
        if signal == SignalType.EXIT_TP1:
            pos.tp1_done = True
        elif signal == SignalType.EXIT_TP2:
            pos.tp2_done = True
        elif signal == SignalType.EXIT_TP3:
            pos.tp3_triggered = True

        # 비용 계산
        fee = exit_qty * order_price * self.commission_pct / 100
        tax = exit_qty * order_price * self.tax_pct / 100
        slippage = abs(current_price - order_price) * exit_qty

        # 매매일지 기록
        self.journal.record(
            symbol      = pos.symbol,
            side        = "SELL",
            qty         = exit_qty,
            price       = order_price,
            entry_price = pos.entry_price,
            exit_reason = reason + (f" | {note}" if note else ""),
            pnl         = pnl,
            fee         = fee,
            tax         = tax,
            slippage    = slippage,
            score       = pos.score,
        )

        pnl_pct = (order_price - pos.entry_price) / pos.entry_price * 100
        self.notifier.send(
            f"{'🟢' if pnl >= 0 else '🔴'} 매도 [{reason}]\n"
            f"종목: {pos.symbol}\n"
            f"{exit_qty}주 @{order_price:,}원 ({pnl_pct:+.2f}%)\n"
            f"PnL: {pnl:+,.0f}원"
        )
        return pnl

    # ── 전 포지션 강제 청산 ──────────────────────────────────
    def force_close_all(self) -> None:
        """15:15 강제 청산"""
        symbols = list(self.risk.positions.keys())
        if not symbols:
            return
        logger.info("강제 청산 시작: %d 종목", len(symbols))
        for sym in symbols:
            pos = self.risk.positions.get(sym)
            if not pos:
                continue
            try:
                price_data = self.client.get_price(sym)
                current_price = int(price_data.get("stck_prpr", pos.entry_price))
                self.exit(pos, current_price, SignalType.EXIT_FORCE, note="15:15 강제청산")
            except Exception as e:
                logger.error("[%s] 강제 청산 실패: %s", sym, e)

    # ── 내부 헬퍼 ─────────────────────────────────────────────
    def _buy_price(self, price: int) -> int:
        """매수 호가 (슬리피지 반영 후 호가단위 정렬)"""
        slipped = price * (1 + self.slippage_bps / 10000)
        return round_to_tick(slipped, price)

    def _sell_price(self, price: int) -> int:
        """매도 호가 (슬리피지 반영 후 호가단위 정렬)"""
        slipped = price * (1 - self.slippage_bps / 10000)
        return round_to_tick(slipped, price)

    def _send_order(self, symbol: str, side: str, qty: int, price: int) -> Optional[str]:
        """주문 전송 (재시도 포함) → 주문번호 반환"""
        for attempt in range(1, self.retry_count + 1):
            try:
                resp = self.client.place_order(symbol, side, qty, price, self.order_type)
                odno = resp.get("output", {}).get("ODNO", "")
                logger.info("주문 성공 [%s] odno=%s", symbol, odno)
                return odno
            except Exception as e:
                logger.warning("주문 실패 [%d/%d] %s: %s", attempt, self.retry_count, symbol, e)
                if attempt < self.retry_count:
                    time.sleep(self.retry_delay)
        logger.error("주문 최종 실패: %s %s %d주", symbol, side, qty)
        return None

    def process_signal(
        self,
        pos: Position,
        indicators: SymbolIndicators,
        current_price: int,
    ) -> float:
        """보유 포지션에 대한 청산 신호 처리

        Returns:
            실현 PnL (청산 없으면 0)
        """
        ma5 = indicators.sma_short.value
        signal = self.strategy.check_exit(
            entry_price     = pos.entry_price,
            current_price   = float(current_price),
            vwap_value      = indicators.vwap.value,
            tp1_done        = pos.tp1_done,
            tp2_done        = pos.tp2_done,
            tp3_triggered   = pos.tp3_triggered,
            ma5_value       = ma5,
        )

        if signal == SignalType.NONE:
            return 0.0

        return self.exit(pos, current_price, signal)
