"""
indicators.py — VWAP / SMA / ORB / 거래량 배율 지표 계산
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional
import logging

logger = logging.getLogger("autotrader.indicators")


@dataclass
class Candle:
    """5분봉 하나"""
    time:   str    # 'HHMMSS'
    open:   float
    high:   float
    low:    float
    close:  float
    volume: int

    @property
    def typical_price(self) -> float:
        return (self.high + self.low + self.close) / 3.0


@dataclass
class ORBState:
    """ORB (Opening Range Breakout) 구간 상태"""
    high:   float = 0.0
    low:    float = float("inf")
    ready:  bool  = False         # ORB 관찰 완료 여부
    candles: list[Candle] = field(default_factory=list)

    def update(self, candle: Candle) -> None:
        self.high = max(self.high, candle.high)
        self.low  = min(self.low,  candle.low)
        self.candles.append(candle)

    def is_breakout(self, price: float) -> bool:
        """ORB 고점 돌파 여부"""
        return self.ready and price > self.high


# ──────────────────────────────────────────────
#  VWAP 계산기
# ──────────────────────────────────────────────
class VWAPCalculator:
    """당일 누적 VWAP (리셋은 매 영업일 9:00에 수행)"""

    def __init__(self) -> None:
        self._cum_pv: float = 0.0
        self._cum_vol: float = 0.0

    def reset(self) -> None:
        self._cum_pv  = 0.0
        self._cum_vol = 0.0

    def update(self, candle: Candle) -> float:
        """봉 추가 후 현재 VWAP 반환"""
        self._cum_pv  += candle.typical_price * candle.volume
        self._cum_vol += candle.volume
        return self.value

    @property
    def value(self) -> float:
        if self._cum_vol == 0:
            return 0.0
        return self._cum_pv / self._cum_vol


# ──────────────────────────────────────────────
#  SMA (단순 이동평균)
# ──────────────────────────────────────────────
class SMACalculator:
    """고정 창 SMA 계산기"""

    def __init__(self, period: int) -> None:
        self.period = period
        self._prices: list[float] = []

    def update(self, price: float) -> Optional[float]:
        self._prices.append(price)
        if len(self._prices) > self.period:
            self._prices.pop(0)
        return self.value

    @property
    def value(self) -> Optional[float]:
        if len(self._prices) < self.period:
            return None
        return sum(self._prices) / self.period

    def is_rising(self) -> bool:
        """최근 2봉 연속 우상향 여부"""
        if len(self._prices) < 2:
            return False
        return self._prices[-1] > self._prices[-2]


# ──────────────────────────────────────────────
#  거래량 배율 계산
# ──────────────────────────────────────────────
class VolumeRatioCalculator:
    """돌파봉 거래량 / 직전 N봉 평균 거래량"""

    def __init__(self, lookback: int = 10) -> None:
        self.lookback = lookback
        self._volumes: list[int] = []

    def update(self, volume: int) -> None:
        self._volumes.append(volume)
        if len(self._volumes) > self.lookback + 1:
            self._volumes.pop(0)

    def current_ratio(self) -> float:
        """최신봉 / 직전 lookback봉 평균 비율"""
        if len(self._volumes) < 2:
            return 0.0
        avg = sum(self._volumes[:-1]) / len(self._volumes[:-1])
        if avg == 0:
            return 0.0
        return self._volumes[-1] / avg


# ──────────────────────────────────────────────
#  종목별 통합 지표 관리자
# ──────────────────────────────────────────────
class SymbolIndicators:
    """종목 하나의 모든 지표를 통합 관리"""

    def __init__(self, symbol: str, ma_short: int = 5, ma_long: int = 20) -> None:
        self.symbol     = symbol
        self.orb        = ORBState()
        self.vwap       = VWAPCalculator()
        self.sma_short  = SMACalculator(ma_short)
        self.sma_long   = SMACalculator(ma_long)
        self.vol_ratio  = VolumeRatioCalculator()
        self.candles:   list[Candle] = []
        self.last_price: float = 0.0

    def add_candle(self, candle: Candle, in_orb_window: bool = False) -> None:
        """새 봉 추가 및 지표 업데이트"""
        self.candles.append(candle)
        self.last_price = candle.close

        self.vwap.update(candle)
        self.sma_short.update(candle.close)
        self.sma_long.update(candle.close)
        self.vol_ratio.update(candle.volume)

        if in_orb_window:
            self.orb.update(candle)

    def set_orb_ready(self) -> None:
        """ORB 관찰 구간 종료 — 이후부터 돌파 신호 감지 가능"""
        self.orb.ready = True
        logger.debug(
            "[%s] ORB 완성: 고점=%.0f 저점=%.0f",
            self.symbol, self.orb.high, self.orb.low,
        )

    @property
    def is_above_vwap(self) -> bool:
        return self.last_price > self.vwap.value > 0

    @property
    def is_ma_aligned(self) -> bool:
        """5MA > 20MA 이면서 둘 다 우상향"""
        s = self.sma_short.value
        l = self.sma_long.value
        if s is None or l is None:
            return False
        return s > l and self.sma_short.is_rising() and self.sma_long.is_rising()

    @property
    def volume_ratio(self) -> float:
        return self.vol_ratio.current_ratio()

    def is_orb_breakout(self, price: float) -> bool:
        return self.orb.is_breakout(price)

    def summary(self) -> dict:
        return {
            "symbol":       self.symbol,
            "price":        self.last_price,
            "vwap":         round(self.vwap.value, 1),
            "sma5":         self.sma_short.value,
            "sma20":        self.sma_long.value,
            "orb_high":     self.orb.high,
            "orb_ready":    self.orb.ready,
            "vol_ratio":    round(self.volume_ratio, 2),
            "above_vwap":   self.is_above_vwap,
            "ma_aligned":   self.is_ma_aligned,
        }


# ──────────────────────────────────────────────
#  KIS API 응답 → Candle 변환 헬퍼
# ──────────────────────────────────────────────
def parse_candle_from_api(row: dict) -> Optional[Candle]:
    """KIS 분봉 API 응답 한 행 → Candle 객체"""
    try:
        return Candle(
            time   = row.get("stck_cntg_hour", "000000"),
            open   = float(row.get("stck_oprc", 0)),
            high   = float(row.get("stck_hgpr", 0)),
            low    = float(row.get("stck_lwpr", 0)),
            close  = float(row.get("stck_prpr", 0)),
            volume = int(row.get("cntg_vol", 0)),
        )
    except (ValueError, KeyError) as e:
        logger.warning("Candle 파싱 실패: %s | 원본: %s", e, row)
        return None
