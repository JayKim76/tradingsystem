"""
strategy.py — 5-체크리스트 스코어링 엔진
진입 신호 판단 및 청산 조건 관리
"""
from __future__ import annotations

import logging
from dataclasses import dataclass
from enum import Enum, auto
from typing import Optional

from .indicators import SymbolIndicators

logger = logging.getLogger("autotrader.strategy")


class SignalType(Enum):
    NONE    = auto()
    ENTER   = auto()
    EXIT_TP1 = auto()
    EXIT_TP2 = auto()
    EXIT_TP3 = auto()
    EXIT_SL  = auto()
    EXIT_FORCE = auto()


@dataclass
class ScoreResult:
    """5점 체크리스트 스코어 결과"""
    orb_breakout:   bool = False   # 1. ORB 돌파
    above_vwap:     bool = False   # 2. VWAP 위
    ma_aligned:     bool = False   # 3. 이평 정배열
    volume_confirm: bool = False   # 4. 거래량 확증
    bid_dominant:   bool = False   # 5. 호가창 매수우세

    @property
    def score(self) -> int:
        return sum([
            self.orb_breakout,
            self.above_vwap,
            self.ma_aligned,
            self.volume_confirm,
            self.bid_dominant,
        ])

    def __str__(self) -> str:
        flags = [
            f"ORB={'✓' if self.orb_breakout else '✗'}",
            f"VWAP={'✓' if self.above_vwap else '✗'}",
            f"MA={'✓' if self.ma_aligned else '✗'}",
            f"VOL={'✓' if self.volume_confirm else '✗'}",
            f"BID={'✓' if self.bid_dominant else '✗'}",
        ]
        return f"[{self.score}/5] " + " ".join(flags)


class StrategyEngine:
    """5-체크리스트 기반 스코어링 & 청산 조건 엔진"""

    def __init__(self, config: dict) -> None:
        strat = config.get("strategy", {})
        tp_cfg = config.get("take_profit", {})
        sl_cfg = config.get("stop_loss", {})

        self.min_score:         int   = int(strat.get("min_score", 3))
        self.volume_multiplier: float = float(strat.get("volume_multiplier", 1.5))
        self.require_vwap:      bool  = bool(strat.get("require_vwap_above", True))

        # 익절 레벨
        self.tp1_pct:  float = float(tp_cfg.get("tp1_pct",  1.5))
        self.tp1_size: float = float(tp_cfg.get("tp1_size", 0.5))
        self.tp2_pct:  float = float(tp_cfg.get("tp2_pct",  3.0))
        self.tp2_size: float = float(tp_cfg.get("tp2_size", 0.3))
        self.tp3_pct:  float = float(tp_cfg.get("tp3_pct",  5.0))

        # 손절
        self.sl_pct:   float = float(sl_cfg.get("sl_pct",   1.0))
        self.vwap_stop: bool = bool(sl_cfg.get("vwap_stop", True))

    # ── 진입 스코어 계산 ──────────────────────────────────────
    def score_entry(
        self,
        indicators: SymbolIndicators,
        current_price: float,
        ask_total: int = 0,
        bid_total: int = 0,
    ) -> ScoreResult:
        result = ScoreResult()

        # 1. ORB 돌파
        result.orb_breakout = indicators.is_orb_breakout(current_price)

        # 2. VWAP 위
        result.above_vwap = current_price > indicators.vwap.value > 0

        # 3. 이평 정배열
        result.ma_aligned = indicators.is_ma_aligned

        # 4. 거래량 확증
        result.volume_confirm = indicators.volume_ratio >= self.volume_multiplier

        # 5. 호가창 매수우세
        if ask_total > 0 or bid_total > 0:
            result.bid_dominant = bid_total > ask_total
        else:
            result.bid_dominant = False   # 데이터 없으면 미충족

        return result

    def should_enter(
        self,
        indicators: SymbolIndicators,
        current_price: float,
        ask_total: int = 0,
        bid_total: int = 0,
    ) -> tuple[bool, ScoreResult]:
        """진입 여부 판단

        Returns:
            (진입 여부, ScoreResult)
        """
        score = self.score_entry(indicators, current_price, ask_total, bid_total)

        # VWAP 필수 조건
        if self.require_vwap and not score.above_vwap:
            return False, score

        if score.score >= self.min_score:
            logger.info("[%s] 진입 신호 %s", indicators.symbol, score)
            return True, score

        return False, score

    # ── 청산 조건 판단 ────────────────────────────────────────
    def check_exit(
        self,
        entry_price: float,
        current_price: float,
        vwap_value: float,
        tp1_done: bool = False,
        tp2_done: bool = False,
        tp3_triggered: bool = False,
        ma5_value: Optional[float] = None,
    ) -> SignalType:
        """현재 보유 포지션 청산 신호 반환"""

        pnl_pct = (current_price - entry_price) / entry_price * 100

        # 손절 (-1% OR VWAP 이탈)
        sl_hit = pnl_pct <= -self.sl_pct
        vwap_hit = self.vwap_stop and vwap_value > 0 and current_price < vwap_value
        if sl_hit or vwap_hit:
            reason = "SL" if sl_hit else "VWAP이탈"
            logger.info("손절 신호 [%s] pnl=%.2f%%", reason, pnl_pct)
            return SignalType.EXIT_SL

        # 3차 익절: tp3 트리거 이후 5MA 이탈
        if tp3_triggered and ma5_value is not None and current_price < ma5_value:
            return SignalType.EXIT_TP3

        # 2차 익절
        if not tp2_done and pnl_pct >= self.tp2_pct:
            return SignalType.EXIT_TP2

        # 1차 익절
        if not tp1_done and pnl_pct >= self.tp1_pct:
            return SignalType.EXIT_TP1

        # 3차 익절 트리거 플래그 (잔량 관리를 위해)
        if not tp3_triggered and pnl_pct >= self.tp3_pct:
            return SignalType.EXIT_TP3

        return SignalType.NONE

    def exit_qty(self, total_qty: int, signal: SignalType, tp1_done: bool = False) -> int:
        """청산 수량 계산"""
        if signal == SignalType.EXIT_TP1:
            return max(1, int(total_qty * self.tp1_size))
        elif signal == SignalType.EXIT_TP2:
            remaining = total_qty if tp1_done else total_qty
            return max(1, int(remaining * self.tp2_size))
        elif signal in (SignalType.EXIT_TP3, SignalType.EXIT_SL, SignalType.EXIT_FORCE):
            return total_qty
        return 0
