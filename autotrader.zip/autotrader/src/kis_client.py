"""
kis_client.py — KIS Developers REST API 래퍼
시세 조회 / 주문 / 잔고 조회
"""
from __future__ import annotations

import logging
import time
from typing import Any

import requests

from .auth import KISAuth

logger = logging.getLogger("autotrader.client")


class KISClient:
    """KIS REST API 래퍼"""

    def __init__(self, auth: KISAuth) -> None:
        self.auth = auth
        self._session = requests.Session()

    def _get(self, path: str, params: dict, tr_id: str) -> dict[str, Any]:
        url = f"{self.auth.base_url}{path}"
        headers = self.auth.get_headers(tr_id=tr_id)
        resp = self._session.get(url, headers=headers, params=params, timeout=10)
        resp.raise_for_status()
        data = resp.json()
        if data.get("rt_cd") not in ("0", 0):
            raise RuntimeError(f"API 오류 [{tr_id}]: {data.get('msg1', data)}")
        return data

    def _post(self, path: str, body: dict, tr_id: str) -> dict[str, Any]:
        url = f"{self.auth.base_url}{path}"
        headers = self.auth.get_headers(tr_id=tr_id)
        resp = self._session.post(url, headers=headers, json=body, timeout=10)
        resp.raise_for_status()
        data = resp.json()
        if data.get("rt_cd") not in ("0", 0):
            raise RuntimeError(f"API 오류 [{tr_id}]: {data.get('msg1', data)}")
        return data

    # ── 시세 조회 ─────────────────────────────────────────────
    def get_price(self, symbol: str) -> dict[str, Any]:
        """현재가 조회 (주식 현재가 시세)"""
        # 모의: FHKST01010100 / 실전: FHKST01010100 (동일)
        tr_id = "FHKST01010100"
        params = {
            "FID_COND_MRKT_DIV_CODE": "J",
            "FID_INPUT_ISCD": symbol,
        }
        data = self._get("/uapi/domestic-stock/v1/quotations/inquire-price", params, tr_id)
        return data.get("output", {})

    def get_orderbook(self, symbol: str) -> dict[str, Any]:
        """호가창 조회 (주식 현재가 호가)"""
        tr_id = "FHKST01010200"
        params = {
            "FID_COND_MRKT_DIV_CODE": "J",
            "FID_INPUT_ISCD": symbol,
        }
        data = self._get("/uapi/domestic-stock/v1/quotations/inquire-asking-price-exp-ccn", params, tr_id)
        return data.get("output1", {})

    def get_minute_candles(self, symbol: str, time_str: str = "090000") -> list[dict]:
        """분봉 데이터 조회 (주식 당일 분봉)

        Args:
            symbol: 종목코드 (6자리)
            time_str: 조회 기준 시각 'HHMMSS'
        """
        tr_id = "FHKST03010200"
        params = {
            "FID_ETC_CLS_CODE": "",
            "FID_COND_MRKT_DIV_CODE": "J",
            "FID_INPUT_ISCD": symbol,
            "FID_INPUT_HOUR_1": time_str,
            "FID_PW_DATA_INCU_YN": "Y",
        }
        data = self._get("/uapi/domestic-stock/v1/quotations/inquire-time-itemchartprice", params, tr_id)
        return data.get("output2", [])

    def get_daily_candles(self, symbol: str, period: str = "D") -> list[dict]:
        """일봉/주봉/월봉 조회

        Args:
            period: D(일봉) / W(주봉) / M(월봉)
        """
        from datetime import datetime
        tr_id = "FHKST03010100"
        today = datetime.now().strftime("%Y%m%d")
        params = {
            "FID_COND_MRKT_DIV_CODE": "J",
            "FID_INPUT_ISCD": symbol,
            "FID_INPUT_DATE_1": "20230101",
            "FID_INPUT_DATE_2": today,
            "FID_PERIOD_DIV_CODE": period,
            "FID_ORG_ADJ_PRC": "0",
        }
        data = self._get("/uapi/domestic-stock/v1/quotations/inquire-daily-itemchartprice", params, tr_id)
        return data.get("output2", [])

    def get_volume_rank(self) -> list[dict]:
        """거래량 순위 조회 (당일 상위 30종목)"""
        tr_id = "FHPST01710000"
        params = {
            "FID_COND_MRKT_DIV_CODE": "J",
            "FID_COND_SCR_DIV_CODE":  "20171",
            "FID_INPUT_ISCD":         "0000",
            "FID_DIV_CLS_CODE":       "0",
            "FID_BLNG_CLS_CODE":      "0",
            "FID_TRGT_CLS_CODE":      "111111111",
            "FID_TRGT_EXLS_CLS_CODE": "000000",
            "FID_INPUT_PRICE_1":      "",
            "FID_INPUT_PRICE_2":      "",
            "FID_VOL_CNT":            "",
            "FID_INPUT_DATE_1":       "",
        }
        data = self._get("/uapi/domestic-stock/v1/ranking/volume", params, tr_id)
        return data.get("output", [])

    def get_gap_rank(self) -> list[dict]:
        """갭상승 종목 조회"""
        tr_id = "FHPST01700000"
        params = {
            "FID_COND_MRKT_DIV_CODE": "J",
            "FID_COND_SCR_DIV_CODE":  "20170",
            "FID_INPUT_ISCD":         "0000",
            "FID_DIV_CLS_CODE":       "0",
            "FID_INPUT_CNT_1":        "0",
            "FID_INPUT_PRICE_1":      "",
            "FID_INPUT_PRICE_2":      "",
            "FID_RSI_VAL":            "",
            "FID_INPUT_DATE_1":       "",
        }
        try:
            data = self._get("/uapi/domestic-stock/v1/ranking/fluctuation", params, tr_id)
            return data.get("output", [])
        except Exception as e:
            logger.warning("갭상승 랭킹 조회 실패: %s", e)
            return []

    # ── 주문 ──────────────────────────────────────────────────
    def place_order(
        self,
        symbol: str,
        side: str,       # "BUY" / "SELL"
        qty: int,
        price: int = 0,
        order_type: str = "00",   # 00=지정가, 01=시장가
    ) -> dict[str, Any]:
        """주식 매수/매도 주문

        Returns:
            {'odno': 주문번호, ...}
        """
        is_paper = self.auth.mode != "real"

        if side == "BUY":
            tr_id = "VTTC0802U" if is_paper else "TTTC0802U"
            sll_buy_dvsn = "02"  # 매수
        else:
            tr_id = "VTTC0801U" if is_paper else "TTTC0801U"
            sll_buy_dvsn = "01"  # 매도

        body = {
            "CANO":            self.auth.cano,
            "ACNT_PRDT_CD":    self.auth.acnt_prdt,
            "PDNO":            symbol,
            "ORD_DVSN":        order_type,
            "ORD_QTY":         str(qty),
            "ORD_UNPR":        str(price) if order_type == "00" else "0",
            "SLL_BUY_DVSN_CD": sll_buy_dvsn,
        }

        logger.info(
            "주문 전송: %s %s %d주 @%s (tr_id=%s)",
            side, symbol, qty, price or "시장가", tr_id,
        )
        return self._post("/uapi/domestic-stock/v1/trading/order-cash", body, tr_id)

    def cancel_order(self, odno: str, qty: int, symbol: str) -> dict[str, Any]:
        """주문 취소"""
        is_paper = self.auth.mode != "real"
        tr_id = "VTTC0803U" if is_paper else "TTTC0803U"
        body = {
            "CANO":         self.auth.cano,
            "ACNT_PRDT_CD": self.auth.acnt_prdt,
            "KRX_FWDG_ORD_ORGNO": "",
            "ORGN_ODNO":    odno,
            "ORD_DVSN":     "00",
            "RVSE_CNCL_DVSN_CD": "02",   # 02=취소
            "ORD_QTY":      str(qty),
            "ORD_UNPR":     "0",
            "QTY_ALL_ORD_YN": "Y",
        }
        return self._post("/uapi/domestic-stock/v1/trading/order-rvsecncl", body, tr_id)

    # ── 잔고 조회 ─────────────────────────────────────────────
    def get_balance(self) -> dict[str, Any]:
        """주식 잔고 조회 (보유 종목 + 예수금)"""
        is_paper = self.auth.mode != "real"
        tr_id = "VTTC8434R" if is_paper else "TTTC8434R"
        params = {
            "CANO":            self.auth.cano,
            "ACNT_PRDT_CD":    self.auth.acnt_prdt,
            "AFHR_FLPR_YN":    "N",
            "OFL_YN":          "",
            "INQR_DVSN":       "02",
            "UNPR_DVSN":       "01",
            "FUND_STTL_ICLD_YN": "N",
            "FNCG_AMT_AUTO_RDPT_YN": "N",
            "PRCS_DVSN":       "01",
            "CTX_AREA_FK100":  "",
            "CTX_AREA_NK100":  "",
        }
        data = self._get("/uapi/domestic-stock/v1/trading/inquire-balance", params, tr_id)
        return {
            "holdings": data.get("output1", []),
            "summary":  data.get("output2", [{}])[0],
        }

    def get_cash(self) -> float:
        """주문 가능 현금 잔고 반환"""
        try:
            bal = self.get_balance()
            summary = bal.get("summary", {})
            return float(summary.get("dnca_tot_amt", 0))
        except Exception as e:
            logger.error("현금 잔고 조회 실패: %s", e)
            return 0.0

    def get_open_orders(self) -> list[dict]:
        """미체결 주문 조회"""
        is_paper = self.auth.mode != "real"
        tr_id = "VTTC8036R" if is_paper else "TTTC8036R"
        params = {
            "CANO":            self.auth.cano,
            "ACNT_PRDT_CD":    self.auth.acnt_prdt,
            "INQR_STRT_DT":    "",
            "INQR_END_DT":     "",
            "SLL_BUY_DVSN_CD": "00",
            "INQR_DVSN":       "01",
            "PDNO":            "",
            "ORD_GNO_BRNO":    "",
            "ODNO":            "",
            "INQR_DVSN_3":     "",
            "INQR_DVSN_1":     "",
            "CTX_AREA_FK100":  "",
            "CTX_AREA_NK100":  "",
        }
        try:
            data = self._get("/uapi/domestic-stock/v1/trading/inquire-psbl-rvsecncl", params, tr_id)
            return data.get("output", [])
        except Exception as e:
            logger.error("미체결 주문 조회 실패: %s", e)
            return []
