"""
utils.py — 로거 / 시간 / 호가단위 유틸
"""
from __future__ import annotations

import logging
import os
from datetime import datetime, time
from zoneinfo import ZoneInfo
from pathlib import Path

KST = ZoneInfo("Asia/Seoul")


# ──────────────────────────────────────────────
#  로거
# ──────────────────────────────────────────────
def setup_logger(name: str = "autotrader", level: str = "INFO", log_dir: str = "logs") -> logging.Logger:
    Path(log_dir).mkdir(parents=True, exist_ok=True)
    today = now_kst().strftime("%Y%m%d")
    log_file = os.path.join(log_dir, f"{today}.log")

    logger = logging.getLogger(name)
    if logger.handlers:
        return logger

    logger.setLevel(getattr(logging, level.upper(), logging.INFO))

    fmt = logging.Formatter(
        "%(asctime)s [%(levelname)s] %(name)s — %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    # 콘솔
    ch = logging.StreamHandler()
    ch.setFormatter(fmt)
    logger.addHandler(ch)

    # 파일
    fh = logging.FileHandler(log_file, encoding="utf-8")
    fh.setFormatter(fmt)
    logger.addHandler(fh)

    return logger


# ──────────────────────────────────────────────
#  시간
# ──────────────────────────────────────────────
def now_kst() -> datetime:
    """현재 KST datetime"""
    return datetime.now(tz=KST)


def now_time_kst() -> time:
    """현재 KST time (시:분:초)"""
    return now_kst().time()


def str_to_time(s: str) -> time:
    """'HH:MM' → time 객체"""
    h, m = map(int, s.split(":"))
    return time(h, m)


def is_market_open() -> bool:
    """현재 주식시장 거래 시간 여부 (09:00~15:30 KST, 평일)"""
    t = now_kst()
    if t.weekday() >= 5:          # 토·일
        return False
    market_open  = time(9, 0)
    market_close = time(15, 30)
    return market_open <= t.time() <= market_close


def time_between(start: str, end: str) -> bool:
    """현재 시각이 start~end 사이인지 (KST, 'HH:MM' 형식)"""
    cur = now_time_kst()
    return str_to_time(start) <= cur <= str_to_time(end)


# ──────────────────────────────────────────────
#  호가 단위
# ──────────────────────────────────────────────
def tick_size(price: int) -> int:
    """KRX 코스피/코스닥 호가단위 반환"""
    if price < 1_000:
        return 1
    elif price < 5_000:
        return 5
    elif price < 10_000:
        return 10
    elif price < 50_000:
        return 50
    elif price < 100_000:
        return 100
    elif price < 500_000:
        return 500
    else:
        return 1_000


def round_to_tick(price: float, base_price: int | None = None) -> int:
    """가격을 호가단위로 내림 반올림"""
    bp = base_price if base_price else int(price)
    ts = tick_size(bp)
    return int(price // ts) * ts


# ──────────────────────────────────────────────
#  숫자 포맷
# ──────────────────────────────────────────────
def fmt_pct(v: float) -> str:
    return f"{v:+.2f}%"


def fmt_krw(v: float) -> str:
    return f"₩{v:,.0f}"
