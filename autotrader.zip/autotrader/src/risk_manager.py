"""
risk_manager.py — 포지션 사이징 & 다층 손실 한도 관리
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Optional

logger = logging.getLogger("autotrader.risk")


class RiskState(Enum):
    OK            = auto()
    DAILY_HALTED  = auto()   # 일일 손실 한도 도달
    MONTHLY_HALT  = auto()   # 월 손실 한도 도달
    LOSING_STREAK = auto()   # 연속 손실
    MAX_TRADES    = auto()   # 일일 최대 거래 도달
    MAX_CONCURRENT = auto()  # 동시 보유 종목 초과


@dataclass
class DailyStats:
    """일별 트레이딩 통계"""
    date:       str   = ""
    trades:     int   = 0
    pnl:        float = 0.0
    wins:       int   = 0
    losses:     int   = 0
    consec_loss: int  = 0


@dataclass
class Position:
    """보유 포지션 정보"""
    symbol:      str
    entry_price: float
    qty:         int
    entry_time:  str
    score:       int        = 0
    tp1_done:    bool       = False
    tp2_done:    bool       = False
    tp3_triggered: bool     = False
    initial_qty: int        = 0

    def __post_init__(self) -> None:
        if self.initial_qty == 0:
            self.initial_qty = self.qty

    def current_pnl_pct(self, current_price: float) -> float:
        return (current_price - self.entry_price) / self.entry_price * 100

    def current_pnl_krw(self, current_price: float) -> float:
        return (current_price - self.entry_price) * self.qty


class RiskManager:
    """포지션 사이징 & 리스크 한도 관리"""

    def __init__(self, config: dict, initial_capital: float) -> None:
        risk_cfg = config.get("risk", {})

        self.risk_per_trade_pct:    float = float(risk_cfg.get("risk_per_trade_pct",    1.5))
        self.max_position_pct:      float = float(risk_cfg.get("max_position_pct",      50.0))
        self.max_concurrent:        int   = int(risk_cfg.get("max_concurrent",           2))
        self.max_daily_trades:      int   = int(risk_cfg.get("max_daily_trades",         8))
        self.daily_loss_limit_pct:  float = float(risk_cfg.get("daily_loss_limit_pct",  3.0))
        self.monthly_loss_limit_pct:float = float(risk_cfg.get("monthly_loss_limit_pct",10.0))
        self.consec_loss_limit:     int   = int(risk_cfg.get("consecutive_loss_limit",   3))
        self.sl_pct:                float = float(config.get("stop_loss", {}).get("sl_pct", 1.0))

        self.capital:    float = initial_capital
        self.month_pnl:  float = 0.0

        from datetime import datetime
        from zoneinfo import ZoneInfo
        today = datetime.now(tz=ZoneInfo("Asia/Seoul")).strftime("%Y%m%d")
        self.daily:    DailyStats  = DailyStats(date=today)
        self.positions: dict[str, Position] = {}

    # ── 상태 검사 ─────────────────────────────────────────────
    def check_state(self) -> RiskState:
        """현재 리스크 상태 반환"""
        # 월 손실 한도
        if self.month_pnl <= -(self.capital * self.monthly_loss_limit_pct / 100):
            return RiskState.MONTHLY_HALT

        # 일일 손실 한도
        if self.daily.pnl <= -(self.capital * self.daily_loss_limit_pct / 100):
            return RiskState.DAILY_HALTED

        # 연속 손실
        if self.daily.consec_loss >= self.consec_loss_limit:
            return RiskState.LOSING_STREAK

        # 일일 최대 거래
        if self.daily.trades >= self.max_daily_trades:
            return RiskState.MAX_TRADES

        # 동시 보유
        if len(self.positions) >= self.max_concurrent:
            return RiskState.MAX_CONCURRENT

        return RiskState.OK

    def can_enter(self) -> bool:
        state = self.check_state()
        if state != RiskState.OK:
            logger.info("진입 불가 — %s", state.name)
            return False
        return True

    # ── 포지션 사이징 ─────────────────────────────────────────
    def calc_position_size(self, entry_price: float) -> int:
        """켈리 기준 / 리스크 기준 포지션 사이징 (주식 수 반환)

        위험 금액 = 자본 × risk_per_trade_pct %
        주식 수   = 위험 금액 / (entry_price × sl_pct%)
        상한      = 자본 × max_position_pct% / entry_price
        """
        if entry_price <= 0 or self.capital <= 0:
            return 0

        risk_amount    = self.capital * self.risk_per_trade_pct / 100
        sl_amount_per  = entry_price * self.sl_pct / 100
        if sl_amount_per <= 0:
            return 0

        size_by_risk   = int(risk_amount / sl_amount_per)
        size_by_cap    = int(self.capital * self.max_position_pct / 100 / entry_price)
        size           = min(size_by_risk, size_by_cap)

        logger.info(
            "포지션 사이징: 자본=%.0f 리스크금액=%.0f → %d주 (상한=%d주)",
            self.capital, risk_amount, size, size_by_cap,
        )
        return max(0, size)

    # ── 포지션 등록/해제 ─────────────────────────────────────
    def open_position(self, position: Position) -> None:
        self.positions[position.symbol] = position
        self.daily.trades += 1
        logger.info(
            "포지션 오픈: %s %d주 @%.0f",
            position.symbol, position.qty, position.entry_price,
        )

    def close_position(self, symbol: str, exit_price: float, qty: Optional[int] = None) -> float:
        """포지션 청산 후 PnL 반환 (원화)"""
        pos = self.positions.get(symbol)
        if not pos:
            logger.warning("청산 대상 없음: %s", symbol)
            return 0.0

        close_qty = qty if qty else pos.qty
        pnl = (exit_price - pos.entry_price) * close_qty

        # 잔량 업데이트
        pos.qty -= close_qty
        if pos.qty <= 0:
            del self.positions[symbol]

        # 통계 업데이트
        self.daily.pnl  += pnl
        self.month_pnl  += pnl

        if pnl >= 0:
            self.daily.wins += 1
            self.daily.consec_loss = 0
        else:
            self.daily.losses += 1
            self.daily.consec_loss += 1

        logger.info(
            "포지션 청산: %s %d주 @%.0f → PnL=%.0f원 (누적=%.0f원)",
            symbol, close_qty, exit_price, pnl, self.daily.pnl,
        )
        return pnl

    def update_capital(self, new_capital: float) -> None:
        self.capital = new_capital

    def reset_daily(self) -> None:
        """일일 통계 초기화 (매일 9:00 호출)"""
        from datetime import datetime
        from zoneinfo import ZoneInfo
        today = datetime.now(tz=ZoneInfo("Asia/Seoul")).strftime("%Y%m%d")
        self.daily = DailyStats(date=today)
        logger.info("일일 통계 초기화: %s", today)

    # ── 상태 요약 ─────────────────────────────────────────────
    def summary(self) -> dict:
        return {
            "capital":       self.capital,
            "daily_pnl":     self.daily.pnl,
            "daily_trades":  self.daily.trades,
            "month_pnl":     self.month_pnl,
            "positions":     len(self.positions),
            "consec_loss":   self.daily.consec_loss,
            "state":         self.check_state().name,
        }
